#ifdef WIN32
#include <windows.h>
#endif
#include <GL/glu.h>

extern int IS_JNI_1_2;
